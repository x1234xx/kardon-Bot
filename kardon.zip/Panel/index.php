<?php
    session_start();
    include './inc/config.php';
    if ( isset($_SESSION['Kardon'])!="" ) 
    {
        header("Location: panel/index.php");
        exit;
    }
?>
<!DOCTYPE html>
<html >
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Kardon C2</title>
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="./img/android-desktop.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">
    <link rel="apple-touch-icon-precomposed" href="./img/ios-desktop.png">
    <meta name="msapplication-TileImage" content="./img/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">
    <link rel="shortcut icon" href="../img/favicon.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.cyan-light_blue.min.css">
    <link rel="stylesheet" href="./css/styles.css">
    <style>
        .mdl-layout {
        align-items: center;
    justify-content: center;
    }
    .mdl-layout__content {
        padding: 24px;
        flex: none;
    }
    </style>
    </head>
    <body class = "mdl-color--<?php echo $c_main; ?>">
    <br><br><br><br><br>
    <?php
    if (isset($_POST['doLogin']))
    {
        $username = $_POST['username'];
        $cpass = $_POST['password'];
        $password = hash("sha256", $_POST['password']);
        if (ctype_alnum($username))
        {
            $sel = $odb->prepare("SELECT id,password,status FROM users WHERE username = :user");
            $sel->execute(array(":user" => $username));
            list($userid,$pass,$status) = $sel->fetch();
            if ($pass != "" || $pass != NULL)
            {
                if ($password == $pass)
                {
                    if ($status != 1)
                    {
                        $i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :user, :ip, :act, UNIX_TIMESTAMP())");
                        $i->execute(array(":user" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":act" => "[BANNED] Tried Logging in"));
                        echo '<center><br><div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--6-col"> <center><h6><font style="color: #F44336;">Banned by administrator</font></h6></center></div><br></center>';
                    }
                    else
                    {
                        $i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :user, :ip, :act, UNIX_TIMESTAMP())");
                        $i->execute(array(":user" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":act" => "Logged in"));
                        $_SESSION['Kardon'] = $username.":".$userid;
                        header("location: ./panel/index.php");
                    }
                } 
                else
                {
                    $act = "Tried Logging in with password: " . $cpass;
                    $i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :user, :ip, :act, UNIX_TIMESTAMP())");
                    $i->execute(array(":user" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":act" => $act));
                     echo '<center><br><div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--6-col"> <center><h6><font style="color: #F44336;">Login Incorrect</font></h6></center></div><br></center>'; 
                }
            } 
            else
            { 
                $act = "Tried Logging in with password: " . $cpass;
                $i = $odb->prepare("INSERT INTO plogs VALUES(NULL, :user, :ip, :act, UNIX_TIMESTAMP())");
                $i->execute(array(":user" => $username, ":ip" => $_SERVER['REMOTE_ADDR'], ":act" => $act));
                echo '<center><br><div class="mdl-shadow--2dp mdl-color--<?php echo $c_mainAlt; ?> mdl-cell mdl-cell--6-col"> <center><h6><font style="color: #F44336;">Login Incorrect</font></h6></center> </div><br></center>'; 
            }
        }
    }
    ?>
    <div class="mdl-layout mdl-js-layout mdl-color--<?php echo $c_main; ?>">
        <main class="mdl-layout__content mdl-color--<?php echo $c_main; ?>">
            <div class="mdl-card mdl-shadow--6dp">
                <div class="mdl-card__title mdl-color--<?php echo $c_sideBarTop; ?> mdl-color-text--white">
                    <h2 class="mdl-card__title-text">Kardon</h2>
                </div>
            <div class="mdl-card__supporting-text mdl-color--<?php echo $c_mainAlt; ?>">
                <form class="login-form" action="" method="POST">
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                    <input class="mdl-textfield__input" type="text" name="username" placeholder="User"/>
                </div>
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                    <input class="mdl-textfield__input" type="password" name="password" placeholder="Pass"/>
                </div>
                <div class="mdl-card__actions mdl-card--border">
                        <button type="submit" name="doLogin" class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect mdl-color-text--blue-grey-400">Log in</button>
                    </div>
                </form>
            </div>
        </main>
    </div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src="js/index.js"></script>
    </body>
</html>