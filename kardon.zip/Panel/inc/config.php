<?php
$dbhost = "localhost"; 		// The host of your database
$dbuser = "root"; 			// The database username
$dbpass = "compoundbow"; 	// The database password
$dbname = "kardon"; 		// The database name

$pluginGuids = [
	"0a1b9b0e-e96d-42dc-97ad-14864d579779" => "Hello World!",
	"7d1e9d25-5634-473d-a2a7-5f1f7e1df170" => "Take Screenshot"
];

$header = "";

$c_sideBarTop;  
$c_sideBarMain; 
$c_header;      
$c_main;   
$c_mainAlt;

$odb = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);

$colours = $odb->query("SELECT * FROM settings");

while ($colour = $colours->fetch(PDO::FETCH_ASSOC))
{
	$c_sideBarTop = $colour['c_sideBarTop'];  
	$c_sideBarMain = $colour['c_sideBarMain']; 
	$c_header = $colour['c_header'];      
	$c_main = $colour['c_main'];   
	$c_mainAlt = $colour['c_mainAlt'];
	$c_chart = $colour['c_chart'];
	$header = $colour['header'];
}



function loggedIn($odb)
{
	if (isset($_SESSION['Kardon']))
	{
		$usern = $_SESSION['Kardon'];
		if ($usern == "" || $usern == NULL)
		{
			return false;
		}else{
			$user = explode(":", $usern);
			if (!ctype_alnum($user[0]))
			{
				return false;
			}else{
				if ($odb->query("SELECT COUNT(*) FROM users WHERE username = '".$user[0]."'")->fetchColumn(0) == 0)
				{
					return false;
				}else{
					$sel = $odb->query("SELECT * FROM users WHERE username = '".$user[0]."'");
					$u = $sel->fetch(PDO::FETCH_ASSOC);
					if ($u['id'] != $user[1])
					{
						return false;
					}else{
						if ($u['status'] == "1")
						{
							return true;
						}else{
							return false;
						}
					}
				}
			}
		}
	}else{
		return false;
	}
}

?>