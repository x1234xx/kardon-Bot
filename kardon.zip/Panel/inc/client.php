<?php
include_once 'config.php';

class client
{
    public $info;
    
    public function __construct($hwid)
    {
        global $odb;
        
        $query = $odb->prepare("SELECT * FROM bots WHERE hwid=:h LIMIT 1");
        $query->bindParam(':h', $hwid);
        $query->execute();

        $this->info = $query->fetch();
    }
}

?>