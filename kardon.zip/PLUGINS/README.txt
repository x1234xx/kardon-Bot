PHP Plugin related files go -> /www/{Path to panel}/panel/plugin/
DLL Plugin files go -> /www/{Path to panel}/plugins/
Plugins are compiled as DLL (See example)
